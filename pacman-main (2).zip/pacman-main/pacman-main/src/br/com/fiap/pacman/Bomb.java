package br.com.fiap.pacman;

public class Bomb extends Item{

    public Bomb(int posicaoX, int posicaoY) {
     
        super(posicaoX, posicaoY);
    }

    public Bomb(boolean visivel) {
        super(visivel);
        //TODO Auto-generated constructor stub
    }

    @Override
    public int getPosicaoX() {
        // TODO Auto-generated method stub
        return super.getPosicaoX();
    }

    @Override
    public int getPosicaoY() {
        // TODO Auto-generated method stub
        return super.getPosicaoY();
    }

    @Override
    public int getTamanhoTela() {
        // TODO Auto-generated method stub
        return super.getTamanhoTela();
    }

    @Override
    public void setPosicaoX(int posicaoX) {
        if(posicaoX<getTamanhoTela()){
            super.setPosicaoX(posicaoX);
        }
        
    }

    @Override
    public void setPosicaoY(int posicaoY) {
        if(posicaoY<getTamanhoTela()){
            super.setPosicaoX(posicaoY);
        }
    }
    
}
