package br.com.fiap.pacman;

public class Booster extends Item{
    int duracao;

  
    public Booster(int posicaoX, int posicaoY) {
        super(posicaoX, posicaoY);
    }

    public Booster(boolean visivel) {
        super(visivel);
    }



    public int getDuracao() {
        return duracao;
    }
    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }
    



    
}
