package br.com.fiap.pacman;

public abstract class GameObject {
    private int posicaoX;
    private int posicaoY;
    private int tamanhoTela;


    public GameObject(int posicaoX, int posicaoY) {
        this.posicaoX = posicaoX;
        this.posicaoY = posicaoY;
    }

    public GameObject() {
    }

    public int getPosicaoX() {

        return posicaoX;
    }

    public void setPosicaoX(int posicaoX) {
        if(posicaoX > this.tamanhoTela){
            System.out.println("Posição inválida" + this.getClass());
        }
        else{
            this.posicaoX = posicaoX;
        }
        
    }

    public int getPosicaoY() {
        return posicaoY;
    }

    public void setPosicaoY(int posicaoY) {
        if(posicaoY > this.tamanhoTela){
            System.out.println("Posição inválida"+ this.getClass());
        }
        else{
            this.posicaoY = posicaoY;
        }
    }

    public int getTamanhoTela() {
        return tamanhoTela;
    }

    public void setTamanhoTela(int tamanhoTela) {

        this.tamanhoTela = tamanhoTela;
    }

    
    
    
    
    
}
