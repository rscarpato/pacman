package br.com.fiap.pacman;

import java.util.Random;

public class Ghost extends GameObject {
    int direcao;
        

    public Ghost(int posicaoX, int posicaoY,int direcao) {
        
        super(posicaoX, posicaoY);
        this.direcao = direcao;
   
    }

    @Override
    public int getPosicaoX() {
        return super.getPosicaoX();
    }

    @Override
    public int getPosicaoY() {
        return super.getPosicaoY();
    }

    @Override
    public int getTamanhoTela() {
        return super.getTamanhoTela();
    }

    @Override
    public void setPosicaoX(int posicaoX) {
        super.setPosicaoX(posicaoX);
    }

    @Override
    public void setPosicaoY(int posicaoY) {
        super.setPosicaoY(posicaoY);
    }

    public boolean podeMover(int x, int y,int dir){
        int testax =0;
        int testay = 0;
        switch(dir){
            case 0:
            testay = getPosicaoY()-10;
            testax = getPosicaoX();
            case 90:
            testax = getPosicaoX()+10;
            testay= getPosicaoY();
            case 180:
            testay = getPosicaoY()+10;
            testax= getPosicaoX();
            case 270:
            testax = getPosicaoX()-10;
            testay= getPosicaoY();
        }
        if(testax > getTamanhoTela() || testax<0 || testay > getTamanhoTela() || testay<0){
            return false;
        }
        else{
            return true;
        } 
    }


    public void mover(){
        Random rnd = new Random();
        
        boolean moveu = false;
        do{
            int dir = rnd.nextInt(4);
            switch(dir){
                case 0:
                if(podeMover(getPosicaoX(), getPosicaoY(), 0)){
                    setPosicaoX(getPosicaoX()+10);
                    moveu = true;
                }              

                case 1:
                if(podeMover(getPosicaoX(), getPosicaoY(), 90)){
                    setPosicaoX(getPosicaoX()-10);
                    moveu = true;
                }
                case 2:
                //setPosicaoX(getPosicaoY()-10);
                if(podeMover(getPosicaoX(), getPosicaoY(), 180)){
                    setPosicaoY(getPosicaoY()-10);
                    moveu = true;
                }
                case 3:
                //setPosicaoX(getPosicaoY()+10);
                if(podeMover(getPosicaoX(), getPosicaoY(), 270)){
                    setPosicaoY(getPosicaoY()+10);
                    moveu = true;
                }
            }

        }while (moveu== false);
        
    }
    
    
}
