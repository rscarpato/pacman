package br.com.fiap.pacman;

public class Item extends GameObject{
    boolean visivel;

    public Item(int posicaoX, int posicaoY) {
        super(posicaoX, posicaoY);
        
    }

    public Item(boolean visivel) {
        this.visivel = visivel;
    }

    public boolean isVisivel() {
        return visivel;
    }

    public void setVisivel(boolean visivel) {
        this.visivel = visivel;
    }
    
}
