package br.com.fiap.pacman;

public class Player extends GameObject{
    

    private int direcao;
    private int vidas;
    private boolean invencivel;

    
     

    public Player(int posicaoX, int posicaoY, int direcao) {
        super(posicaoX, posicaoY);
        this.direcao = direcao;
    }


    public Player() {
     
    }   
     

    @Override
    public int getPosicaoX() {
        return super.getPosicaoX();
    }

    @Override
    public int getPosicaoY() {
        return super.getPosicaoY();
    }

    @Override
    public int getTamanhoTela() {
        return super.getTamanhoTela();
    }

    @Override
    public void setPosicaoX(int posicaoX) {
        super.setPosicaoX(posicaoX);
    }

    @Override
    public void setPosicaoY(int posicaoY) {
        super.setPosicaoY(posicaoY);
    }

    @Override
    public void setTamanhoTela(int tamanhoTela) {
        super.setTamanhoTela(tamanhoTela);
    }

    

    public boolean podeMover(){
        int testax =0;
        int testay = 0;
        switch(getDirecao()){
            case 0:
            testay = getPosicaoY()-10;
            testax = getPosicaoX();
            case 90:
            testax = getPosicaoX()+10;
            testay= getPosicaoY();
            case 180:
            testay = getPosicaoY()+10;
            testax= getPosicaoX();
            case 270:
            testax = getPosicaoX()-10;
            testay= getPosicaoY();
        }
        if(testax > getTamanhoTela() || testax<0 || testay > getTamanhoTela() || testay<0){
            return false;
        }
        else{
            return true;
        }

    }

    public void mover(){
        if(podeMover()){
            switch(getDirecao()){
                case 0:
                setPosicaoY(getPosicaoY()-10);  
                case 90:
                setPosicaoX(getPosicaoX()+10);
                case 180:
                setPosicaoY(getPosicaoY()+10);
                case 270:
                setPosicaoX(getPosicaoX()-10);
            }
        }
    }

    public int getDirecao() {
        return direcao;
    }


    public void setDirecao(int dir) {

       
        switch(dir){
            case 0:
            this.direcao = 0; 
            case 1:
            this.direcao = 90; 
            case 2:
            this.direcao = 180; 
            case 3:
            this.direcao = 270; 
        }
    }

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
        this.vidas = vidas;
    }

    public boolean isInvencivel() {
        return invencivel;
    }

    public void setInvencivel(boolean invencivel) {
        this.invencivel = invencivel;
    }


}
